        import pickle
        import json
        import pandas as pd

        # Load model
        with open("model.pkl", "rb") as f:
            model = pickle.load(f)

        # Load features
        with open("features.json", "r") as f:
            feature_columns = json.load(f)

        # Example usage
        def predict(input_df):
            assert all(col in input_df.columns for col in feature_columns), "Missing columns"
            return model.predict(input_df[feature_columns])

        # Example input
        # df = pd.read_csv("your_data.csv")
        # preds = predict(df)
        